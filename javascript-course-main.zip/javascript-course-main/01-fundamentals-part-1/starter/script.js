// JavaScript Fundamentals - Part 1
// We'll write our code here!
